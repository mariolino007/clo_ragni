Clothoids
=========

G1 and G2 fitting with clothoids, spline of clothoids, circle arc and
biarc. Support interpolation using Eigen3 LM solver and Ipopt solver.

Based on the `work <http://ebertolazzi.github.io/Clothoids/>`__ of Enrico Bertolazzi
