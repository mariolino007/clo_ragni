Clothoids
=========

G1 and G2 fitting with clothoids, spline of clothoids, circle arc and
biarc.

Based on the `work <http://ebertolazzi.github.io/Clothoids/>`__ of Enrico Bertolazzi
